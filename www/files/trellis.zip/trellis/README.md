# VinFinder.org Coding Challenge

Jordan Majd's solution to VinFinder.org Coding Challenge

## Gettings Started

1. Install the project dependencies: `npm install`.
1. Create file for environment variables by copying the example: `cp .env.example .env`.
  - By default `.env` will contain the challenge key.
1. Run the application `npm start`.
1. Open your browser to [http://localhost:8080/?t=1](http://localhost:8080/?t=1)
1. Use `3GNFK16T64G116131` or `JM1NDAM72H0102337` as the test VIN numbers